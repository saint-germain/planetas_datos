Perturbed Solar Nebula model with A=0.7, f=1. See input.py for more info.
